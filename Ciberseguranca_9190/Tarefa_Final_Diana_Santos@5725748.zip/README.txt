PROJETO: Adaptive Breach System (Tarefa Final)
DISCIPLINA: Cibersegurança - UFCD 9190
FORMANDA: Diana Santos

------------------------
| DESCRIÇÃO DO PROJETO |
------------------------
O Adaptive Breach System é um simulador avançado de exploração de redes. 
Num ambiente de matriz 4x4, o analista deve gerir recursos críticos 
(Energia e Risco) para neutralizar ameaças e extrair dados prioritários.

----------------------------
| CONTEÚDO DO PACOTE (ZIP) |
----------------------------
1. Adaptive_Breach_System.py   -> Código fonte original (Python).
2. BreachSystem.exe            -> Executável otimizado para Windows.
3. BreachSystem                -> Executável nativo para Linux.
4. README.txt                  -> Documentação técnica.

----------------------------
| REQUISITOS IMPLEMENTADOS |
----------------------------
O sistema foi elevado para um nível de simulação dinâmica:
- Inteligência Adaptativa: Existe 20% de probabilidade de a rede se 
  reconfigurar a cada turno. As Flags podem mudar de posição (Relocation), 
  exigindo novos scans estratégicos.
- Validação Estrita: Sistema de proteção contra inputs inválidos ou 
  vazios, com mensagens de erro temporárias e limpeza automática de ecrã.
- Fidelidade Visual: Interface otimizada com espaçamento amplo para 
  melhor leitura das coordenadas no terminal.
- Menu de Ajuda: Acesso instantâneo à legenda de nós e comandos via tecla '9'.
- Condição de Vitória: Captura de pelo menos 2 flags e pontuação positiva.

--------------------------
| INSTRUÇÕES DE EXECUÇÃO |
--------------------------
- Windows: Executar o "BreachSystem.exe". Recomenda-se maximizar a 
  janela do terminal para visualizar a matriz corretamente.
- Linux: Dar permissão (chmod +x BreachSystem) e executar via terminal.
- Python: python3 Adaptive_Breach_System.py.

----------------
| NOTAS FINAIS |
----------------
O projeto foi desenvolvido nativamente em ambiente Linux. No entanto, prevendo 
a possibilidade de o sistema de destino ser Windows ou Linux, utilizei a 
ferramenta Bottles para gerar o executável .exe através do PyInstaller. 

Esta abordagem garante a portabilidade total do projeto, assegurando que a 
experiência de jogo e a lógica de movimentação de flags se mantêm idênticas 
independentemente do sistema operativo utilizado pelo utilizador.