/**
 * Classe base abstrata para qualquer veículo da garagem.
 * As subclasses (Carro, Mota, Autocarro) acrescentam os campos próprios
 * de cada tipo e implementam getTipo() e getInfoEspecifica().
 */
public abstract class Veiculo {

    protected String matricula;
    protected String marca;
    protected String modelo;
    protected int ano;
    protected String cor;
    protected double preco;

    public Veiculo(String matricula, String marca, String modelo, int ano, String cor, double preco) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
        this.preco = preco;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAno() {
        return ano;
    }

    public String getCor() {
        return cor;
    }

    public double getPreco() {
        return preco;
    }

    /** Ex: "Carro", "Mota", "Autocarro" */
    public abstract String getTipo();

    /** Informação própria de cada tipo de veículo (ex: numero de portas, cilindrada, etc). */
    public abstract String getInfoEspecifica();

    @Override
    public String toString() {
        return String.format("[%-9s] %s %s (%d) | Matricula: %-8s | Cor: %-10s | Preco: %8.2f EUR | %s",
                getTipo(), marca, modelo, ano, matricula, cor, preco, getInfoEspecifica());
    }
}
